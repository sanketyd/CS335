Compiler Project

Group 7

Members
 	Abhisek Panda 150026
	Raktim Mitra  150562
	Sanket 150634
Features Implemented:
	Basic Arithmetic Operations
	If-Else(Nested If-Else)
	Simple and Nested for, while, do while loops.
	Switch Cases
	Local Scoping
	Functions(Recursive functions too) , with restricted support for accessing multidimensional arrays
	Dynamic Memory allocation
	Mulltidimensional Arrays
	Char Arrays, basic character arithmetic, character printing
	Classes and Object creations, (with support to int data types.) Parameters are accessed using this keyword.

Test Cases
	simple class                           --- ->		class_old.java
	Class and Object creation              --- -> 		class_func.java
	(with method calling via object)
	Recursive Functions                    --- -> 		fact.java (factorial)
	Multiplication Of  3x3 matrices        --- -> 		matmult.java
	while loop                             --- -> 		while.java
	for loop                               --- ->		for.java
	Array passing by reference to function --- ->		func_arr.java
	switch case test                       --- ->		switch.java
    Character array test                   --- ->       char_test.java
