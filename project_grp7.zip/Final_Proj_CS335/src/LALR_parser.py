#!/usr/bin/env python
import sys
import ply.lex as lex
import ply.yacc as yacc
import lexer
from three_address_code import TAC
from new_sym_table import ScopeTable
import global_vars as g

TAC = TAC()
ST = ScopeTable()
class_table = dict()
stackbegin = []
stackend = []

rules_store = []

global_return_type = None
field_count = 0

# Section 19.2
def p_Goal(p):
    '''Goal : CompilationUnit'''
    rules_store.append(p.slice)

# Section 19.3
def p_Identfier(p):
    '''Identifier : IDENTIFIER'''
    p[0] = p[1]

def p_Literal(p):
    ''' Literal : IntegerConst
    | FloatConst
    | CharConst
    | StringConst
    | NullConst
    '''
    p[0] = p[1]
    p[0]['idVal'] = str(p[0]['idVal'])
    p[0]['is_var'] = False
    rules_store.append(p.slice)

def p_IntegerConst(p):
    '''
    IntegerConst : INT_CONSTANT
    '''
    p[0] = {
        'idVal' : p[1],
        'type' : 'INT'
    }


def p_FloatConst(p):
    '''
    FloatConst : FLOAT_CONSTANT
    '''
    p[0] = {
        'idVal' : p[1],
        'type' : 'FLOAT'
    }


def p_CharConst(p):
    '''
    CharConst : CHAR_CONSTANT
    '''
    p[0] = {
        'idVal' : p[1],
        'type' : 'CHAR'
    }


def p_StringConst(p):
    '''
    StringConst : STR_CONSTANT
    '''
    p[0] = {
        'idVal' : p[1],
        'type' : 'STR'
    }


def p_NullConst(p):
    '''
    NullConst : NULL
    '''
    p[0] = {
        'idVal' : p[1],
        'type' : 'NULL'
    }


# Section 19.4
def p_Type(p):
    ''' Type : PrimitiveType
    | ReferenceType
    '''
    p[0] = p[1]
    rules_store.append(p.slice)

def p_PrimitiveType(p):
    ''' PrimitiveType : NumericType
    | BOOLEAN
    '''
    if type(p[1]) != type({}):
        p[0] = {
            'type' : 'INT'  # treat boolean as integer for now
        }
    else:
        p[0] = p[1]
    rules_store.append(p.slice)

def p_NumericType(p):
    ''' NumericType : IntegralType
    | FloatingPointType
    '''
    p[0] = p[1]
    rules_store.append(p.slice)

def p_IntegralType(p):
    ''' IntegralType : BYTE
    | SHORT
    | INT
    | LONG
    | CHAR
    '''
    p[0] = {
        'type' : p[1].upper()
    }
    rules_store.append(p.slice)

def p_FloatingPointType(p):
    ''' FloatingPointType : FLOAT
    | DOUBLE
    '''
    p[0] = {
        'type' : p[1].upper()
    }
    rules_store.append(p.slice)

def p_ReferenceType(p):
    ''' ReferenceType : ArrayType
    | ClassType
    '''
    p[0] = p[1]
    rules_store.append(p.slice)

def p_ClassType(p):
    '''
    ClassType : Name
    '''
    p[0] = p[1]
    p[0]['type'] = 'class'
    rules_store.append(p.slice)

def p_ArrayType(p):
    ''' ArrayType : PrimitiveType Dims
    | Name Dims
    '''
    if 'place' not in p[1].keys():
        p[0] = {
            'type' : p[1]['type']
        }
    else:
        p[0] = {
            'type' : p[1]['place'],
        }
    p[0]['is_array'] = True
    p[0]['arr_size'] = p[2]
    rules_store.append(p.slice)

# Section 19.5
def p_Name(p):
    ''' Name : SimpleName
    | QualifiedName'''
    p[0] = p[1]
    p[0]['is_var'] = True
    rules_store.append(p.slice)

def p_SimpleName(p):
    ''' SimpleName : Identifier'''
    p[0] = {
        'place' : p[1],
    }
    rules_store.append(p.slice)

def p_QualifiedName(p):
    ''' QualifiedName : Name DOT Identifier'''
    attributes = ST.lookup(p[1]['place'])
    var_list = class_table[attributes['type']]['fields']
    func_list = class_table[attributes['type']]['methods']
    index = -1
    for i, var in enumerate(var_list):
        if var[0] == p[3]:
            index = i
            is_func = False
            break
    if index == -1:
        for i, var in enumerate(func_list):
            if var['name'] == p[3]:
                index = i
                is_func = True
                break
    if index == -1:
        raise Exception("No such member present!!")

    if not is_func:
        p[0] = {}
        p[0]['name'] = p[1]['place'] + '_obj_' + attributes['type']
        p[0]['access_type'] = 'array'
        p[0]['index'] = str(index)
        p[0]['arr_size'] = [str(class_table[attributes['type']]['count'])]
        p[0]['type'] = 'INT'
        p[0]['is_array'] = True
    else:
        p[0] = {}
        p[0]['place'] = p[3]
        p[0]['this'] = p[1]['place'] + '_obj_' + attributes['type']
        p[0]['var_list'] = var_list

    rules_store.append(p.slice)

# Section 19.6
def p_CompilationUnit(p):
    '''
    CompilationUnit : PackageDeclaration ImportDeclarations TypeDeclarations
    | PackageDeclaration ImportDeclarations
    | PackageDeclaration TypeDeclarations
    | ImportDeclarations TypeDeclarations
    | PackageDeclaration
    | ImportDeclarations
    | TypeDeclarations
    |
    '''
    rules_store.append(p.slice)

def p_ImportDeclarations(p):
    '''
    ImportDeclarations : ImportDeclaration
    | ImportDeclarations ImportDeclaration
    '''
    rules_store.append(p.slice)

def p_TypeDeclarations(p):
    '''
    TypeDeclarations : TypeDeclaration
    | TypeDeclarations TypeDeclaration
    '''
    global class_table
    if(len(p)==2):
        class_table[p[1]['name']] = p[1]
        p[0] = [p[1]]
    else:
        class_table[p[2]['name']] = p[2]
        p[0] = p[1] + [p[2]]
    rules_store.append(p.slice)

def p_PackageDeclaration(p):
    '''
    PackageDeclaration : PACKAGE Name STMT_TERMINATOR
    '''
    rules_store.append(p.slice)

def p_ImportDeclaration(p):
    '''
    ImportDeclaration : SingleTypeImportDeclaration
    | TypeImportOnDemandDeclaration
    '''
    rules_store.append(p.slice)

def p_SingleTypeImportDeclaration(p):
    '''
    SingleTypeImportDeclaration : IMPORT Name STMT_TERMINATOR
    '''
    rules_store.append(p.slice)

def p_TypeImportOnDemandDeclaration(p):
    '''
    TypeImportOnDemandDeclaration : IMPORT Name DOT MULT STMT_TERMINATOR
    '''
    rules_store.append(p.slice)

def p_TypeDeclaration(p):
    '''
    TypeDeclaration : ClassDeclaration
    | STMT_TERMINATOR
    '''
    p[0] = p[1]
    rules_store.append(p.slice)

def p_Modifiers(p):
    '''
    Modifiers : Modifier
    | Modifiers Modifier
    '''
    if(len(p)==2):
        p[0] = [p[1]]
    else:
        p[0] = p[1] + [p[2]]
    rules_store.append(p.slice)

def p_Modifier(p):
    '''
    Modifier : STATIC
    | FINAL
    '''
    p[0] = p[1]

    rules_store.append(p.slice)

# Section 19.8
def p_ClassDeclaration(p):
    '''
    ClassDeclaration : CLASS Identifier ClsMark Inherit ClassBody
    | CLASS Identifier ClsMark ClassBody
    '''
    if(len(p) == 6):
        p[5]['name'] = p[2]
        p[5]['parent'] = p[4]['place']
        p[0] = p[5]
    else:
        p[4]['name'] = p[2]
        p[4]['parent'] = None
        p[0] = p[4]
    ST.insert_in_sym_table(p[2],'class')
    rules_store.append(p.slice)

def p_ClsMark(p):
    ''' ClsMark : '''
    g.curr_class = p[-1]
    g.members = []
    g.func_members = []

def p_Inherit(p):
    '''
    Inherit : EXTENDS ClassType
    '''
    p[0] = p[2]
    rules_store.append(p.slice)

def p_ClassBody(p):
    '''
    ClassBody : BLOCK_OPENER BLOCK_CLOSER
    | BLOCK_OPENER ClassBodyDeclarations BLOCK_CLOSER
    '''
    if(len(p) == 4):
        global field_count
        p[0] = dict()
        p[0]['fields'] = [i for i in p[2] if type(i) != type({})]
        p[0]['methods'] = [i for i in p[2] if type(i) == type({})]
        p[0]['count'] = len(p[0]['fields'])
    field_count = 0
    rules_store.append(p.slice)

def p_ClassBodyDeclarations(p):
    '''
    ClassBodyDeclarations : ClassBodyDeclaration
    | ClassBodyDeclarations ClassBodyDeclaration
    '''
    if(len(p)==2):
        p[0] = [p[1]]
    else:
        p[0] = p[1] + [p[2]]

    rules_store.append(p.slice)

def p_ClassBodyDeclaration(p):
    '''
    ClassBodyDeclaration : ClassMemberDeclaration FieldMark
    | ConstructorDeclaration
    | StaticInitializer
    '''
    if(len(p)==3):
        p[0] = p[1]
    rules_store.append(p.slice)

def p_ClassMemberDeclaration(p):
    '''
    ClassMemberDeclaration : FieldDeclaration
    | MethodDeclaration
    '''
    p[0] = p[1]
    rules_store.append(p.slice)

def p_FieldMark(p):
    '''
    FieldMark :
    '''
    rules_store.append(p.slice)


def p_FieldDeclaration(p):
    '''
    FieldDeclaration : Modifiers Type VariableDeclaratorId STMT_TERMINATOR
    | Type VariableDeclaratorId STMT_TERMINATOR
    '''
    if(len(p) == 4):
        p[0] = [p[2],p[1],None]
    else:
        p[0] = [p[3],p[2],p[1]]
    g.members.append(p[0])

    rules_store.append(p.slice)

def p_VariableDeclarators(p):
    '''
    VariableDeclarators : VariableDeclarator
    | VariableDeclarators COMMA VariableDeclarator
    '''
    if len(p) == 2:
        p[0] = [p[1]]
    else:
        p[0] = p[1] + [p[3]]

    rules_store.append(p.slice)

def p_VariableDeclarator(p):
    '''
    VariableDeclarator : VariableDeclaratorId
    | VariableDeclaratorId ASSIGN VariableInitializer
    '''
    p[0] = {}
    to_emit = []
    if len(p) == 2:
        p[0]['place'] = p[1]
        return
    elif type(p[3]) != type({}):
        return
    if 'fields' in p[3].keys():
        obj_name = p[1] + "_obj_" + p[3]['name']
        size = p[3]['count']
        # to_emit.append(['declare', p[1], t, p[3]['type'], ST])
        t = ST.get_temp_var()
        to_emit.append([t, str(size), '', '=', ST])
        to_emit.append(['declare', obj_name, t, 'INT', ST])
        p[0]['class_name'] = p[3]['name']
        p[0]['place'] = p[1]
        p[0]['emit_intrs'] = to_emit
        ST.insert_in_sym_table(obj_name, 'INT', is_array=True, arr_size=size)
        return

    if 'is_array' in p[3].keys() and p[3]['is_array']:
        t = ST.get_temp_var()
        to_emit.append([t, '1', '', '=', ST])
        for i in p[3]['place']:
            to_emit.append([t, t, i, '*', ST])
        to_emit.append(['declare', p[1], t, p[3]['type'], ST])
        p[0]['place'] = (p[1], p[3]['place'])
        p[0]['type'] = p[3]['type']
        p[0]['emit_intrs'] = to_emit

    elif 'ret_type' in p[3].keys():
        p[0]['place'] = p[1]
        p[0]['type'] = p[3]['ret_type']
        to_emit.append([p[1], p[3]['place'], '', '=', ST])
        p[0]['emit_intrs'] = to_emit
    else:
        to_emit.append([p[1], p[3]['place'], '', p[2], ST])
        p[0]['place'] = p[1]
        if 'is_var' not in p[3]:
            attributes = ST.lookup(p[3]['place'])
            if attributes == None:
                p[0]['type'] = p[3]['type']
                p[0]['emit_intrs'] = to_emit
                return
            if 'is_array' in attributes and attributes['is_array']:
                p[0]['is_array'] = True
                p[0]['arr_size'] = attributes['arr_size']
            else:
                p[0]['is_array'] = False

        p[0]['type'] = p[3]['type']
        p[0]['emit_intrs'] = to_emit
    rules_store.append(p.slice)

def p_VariableDeclaratorId(p):
    '''
    VariableDeclaratorId : Identifier
    '''
    p[0] = p[1]
    rules_store.append(p.slice)

def p_VariableInitializer(p):
    '''
    VariableInitializer : Expression
    | ArrayInitializer classMark
    '''
    p[0] = p[1]
    rules_store.append(p.slice)

def p_classMark(p):
    '''
    classMark :
    '''
def p_MethodDeclaration(p):
    '''
    MethodDeclaration : MethodHeader MethodDeclMark2 MethodBody
    '''
    p[0] = p[1]
    TAC.emit('ret','','','', ST)
    ST.end_scope(TAC)
    rules_store.append(p.slice)

def p_MehodDeclMark2(p):
    '''
    MethodDeclMark2 :
    '''
    par_scope = ST.get_parent_scope()
    ST.insert_in_sym_table(p[-1]['name'], p[-1]['type'], is_func=True, args=p[-1]['args'], scope=par_scope)

def p_MethodHeader(p):
    '''
    MethodHeader : Modifiers Type MethodDeclarator Throws
    | Modifiers Type MethodDeclarator
    | Type MethodDeclarator Throws
    | Type MethodDeclarator
    | Modifiers VOID MethodDeclarator Throws
    | Modifiers VOID MethodDeclarator
    | VOID MethodDeclarator Throws
    | VOID MethodDeclarator
    '''
    p[0] = {}
    if len(p) == 5:
        # TODO
        pass
    elif len(p) == 4:
        # TODO
        pass
    elif len(p) == 3:
        p[0]['name'] = p[2]['name']
        p[0]['args'] = p[2]['args']
        if type(p[1]) == type({}):
            if 'is_array' in p[1].keys():
                p[0]['type'] = (p[1]['type'], p[1]['arr_size'])
            else:
                p[0]['type'] = (p[1]['type'], 0)
        else:
            p[0]['type'] = 'VOID'
        global global_return_type
        global_return_type = p[0]['type']
    rules_store.append(p.slice)

def p_MethodDeclarator(p):
    '''
    MethodDeclarator : Identifier L_PAREN MethodDeclMark1 R_PAREN
    | Identifier L_PAREN MethodDeclMark1 FormalParameterList R_PAREN
    '''
    g.func_members.append(p[1])
    p[0] = {
        'name' : p[1],
    }
    if len(p) == 6:
        p[0]['args'] = p[4]
    else:
        p[0]['args'] = []

    stackbegin.append(p[1])
    stackend.append(p[1])
    if len(p) == 6:
        for i in range(len(p[4])):
            parameter = p[4][i]
            if 'is_array' in parameter and parameter['is_array']:
                try:
                    size = parameter['arr_size']
                    tmp = p[4][i + size]
                    dims = []
                    for j in range(size):
                        dims.append(p[4][i + 1 + j]['place'])
                    ST.insert_in_sym_table(parameter['place'],parameter['type'], is_array=True, arr_size=dims)
                except:
                    raise Exception("Array passing guidelines not followed properly for arg %s" %(i))
            else:
                ST.insert_in_sym_table(parameter['place'],parameter['type'], is_array=False)
    TAC.emit('func', p[1], '', '', ST)
    TAC.emit('arg', 'this', '', '', ST)
    for arg in p[0]['args']:
        TAC.emit('arg', arg['place'], '', '', ST)
    rules_store.append(p.slice)

def p_MehodDeclMark1(p):
    '''
    MethodDeclMark1 :
    '''
    ST.create_new_table(p[-2], TAC)

def p_FormalParametersList(p):
    '''
    FormalParameterList : FormalParameter
    | FormalParameterList COMMA FormalParameter
    '''
    if len(p) == 2:
        p[0] = [p[1]]
    else:
        p[0] = p[1] + [p[3]]
    rules_store.append(p.slice)

def p_FormalParameter(p):
    '''
    FormalParameter : Type VariableDeclaratorId
    '''
    p[0] = {
        'place' : p[2],
        'type' : p[1]['type']
    }
    if 'is_array' in p[1].keys() and p[1]['is_array']:
        p[0]['is_array'] = True
        p[0]['arr_size'] = p[1]['arr_size']
    rules_store.append(p.slice)

def p_Throws(p):
    '''
    Throws : THROWS ClassTypeList
    '''
    rules_store.append(p.slice)

def p_ClassTypeList(p):
    '''
    ClassTypeList : ClassType
    | ClassTypeList COMMA ClassType
    '''
    rules_store.append(p.slice)

def p_MethodBody(p):
    '''
    MethodBody : Block
    | STMT_TERMINATOR
    '''
    rules_store.append(p.slice)

def p_StaticInitializer(p):
    '''
    StaticInitializer : STATIC Block
    '''
    rules_store.append(p.slice)

def p_ConstructorDeclaration(p):
    '''
    ConstructorDeclaration : Modifiers ConstructorDeclarator Throws ConstructorBody
    | Modifiers ConstructorDeclarator ConstructorBody
    | ConstructorDeclarator Throws ConstructorBody
    | ConstructorDeclarator ConstructorBody
    '''
    if(len(p) == 3):
        pass
    rules_store.append(p.slice)

def p_ConstructorDeclarator(p):
    '''
    ConstructorDeclarator : SimpleName L_PAREN FormalParameterList R_PAREN
    | SimpleName L_PAREN R_PAREN
    '''
    rules_store.append(p.slice)

def p_ConstructorBody(p):
    '''
    ConstructorBody : BLOCK_OPENER ExplicitConstructorInvocation BlockStatements BLOCK_CLOSER
    | BLOCK_OPENER BlockStatements BLOCK_CLOSER
    | BLOCK_OPENER BLOCK_CLOSER
    '''
    rules_store.append(p.slice)
    #| BLOCK_OPENER ExplicitConstructorInvocation BLOCK_CLOSER

def p_ExplicitConstructorInvocation(p):
    '''
    ExplicitConstructorInvocation : THIS L_PAREN ArgumentList R_PAREN STMT_TERMINATOR
    | THIS L_PAREN R_PAREN STMT_TERMINATOR
    | SUPER L_PAREN ArgumentList R_PAREN STMT_TERMINATOR
    | SUPER L_PAREN R_PAREN STMT_TERMINATOR
    '''
    rules_store.append(p.slice)

# Section 19.10
def p_ArrayInitializer(p):
    '''
    ArrayInitializer : BLOCK_OPENER VariableInitializers BLOCK_CLOSER
    | BLOCK_OPENER BLOCK_CLOSER
    '''
    ## TODO
    rules_store.append(p.slice)

def p_VariableInitializers(p):
    '''
    VariableInitializers : VariableInitializer
    | VariableInitializers COMMA VariableInitializer
    '''
    rules_store.append(p.slice)

# Section 19.11
def p_Block(p):
    '''
    Block : BLOCK_OPENER BLOCK_CLOSER
    | BLOCK_OPENER BlockStatements BLOCK_CLOSER
    '''
    rules_store.append(p.slice)

def p_BlockStatements(p):
    '''
    BlockStatements : BlockStatement
    | BlockStatements BlockStatement
    '''
    rules_store.append(p.slice)

def p_BlockStatement(p):
    '''
    BlockStatement : LocalVariableDeclarationStatement
    | Statement
    '''
    p[0] = p[1]
    rules_store.append(p.slice)

def p_LocalVariableDeclarationStatement(p):
    '''
    LocalVariableDeclarationStatement : LocalVariableDeclaration STMT_TERMINATOR
    '''
    p[0] = p[1]
    rules_store.append(p.slice)

def p_LocalVariableDeclaration(p):
    '''
    LocalVariableDeclaration : Type VariableDeclarators
    '''
    for symbol in p[2]:
        if 'class_name' in symbol.keys():
            if p[1]['place'] != symbol['class_name']:
                raise Exception("Wrong class assignments")
            ST.insert_in_sym_table(symbol['place'], symbol['class_name'])
            continue
        i = symbol['place']
        if 'type' in symbol:
            t = symbol['type']
        else:
            t = None
        if 'is_array' not in p[1].keys():
            if t == None:
                ST.insert_in_sym_table(idName=i, idType=p[1]['type'])
                return
            if len(i) == 2:
                raise Exception("Array cannot be assigned to a primitive type")
            if len(t) == 2 and t[1] != 0:
                raise Exception("Mismatch in function return: %s" %(i))
            if type(t) == type(tuple([])) and t[0] != p[1]['type']:
                raise Exception("Type mismatch: Expected %s, but got %s" %(p[1]['type'], t[0]))
            if type(t) != type(tuple([])) and t != p[1]['type']:
                raise Exception("Type mismatch: Expected %s, but got %s" %(p[1]['type'], t))
            ST.insert_in_sym_table(idName=i, idType=p[1]['type'])
        else:
            if type(i) != type(' '):
                if t == None:
                    ST.insert_in_sym_table(idName=i[0], idType=p[1]['type'], is_array=True, arr_size=i[1])
                    return
                if len(i) == 1:
                    raise Exception("Primitive types cannot be assigned to array")
                if len(i[1]) != int(p[1]['arr_size']):
                    raise Exception("Dimension mismatch for array: %s" %(i[0]))
                if type(t) != type(tuple([])) and t != p[1]['type']:
                    raise Exception("Type mismatch: Expected %s, but got %s" %(p[1]['type'], t))
                if type(t) == type(tuple([])) and t[0] != p[1]['type']:
                    raise Exception("Type mismatch: Expected %s, but got %s" %(p[1]['type'], t[0]))
                ST.insert_in_sym_table(idName=i[0], idType=p[1]['type'], is_array=True, arr_size=i[1])
            else:
                if t == None:
                    ST.insert_in_sym_table(idName=i, idType=p[1]['type'], is_array=True, arr_size=0)
                    return
                if type(t) == type(tuple([])) and t[0] != p[1]['type']:
                    raise Exception("%s and %s types are not compatible" %(t[0], p[1]['type']))
                if 'is_array' not in symbol:
                    raise Exception("Array assignment was expected: %s" %(i))
                if 'is_array' in symbol and t != p[1]['type']:
                    raise Exception("%s and %s types are not compatible" %(t, p[1]['type']))
                if 'is_array' in symbol and len(symbol['arr_size']) != p[1]['arr_size']:
                    raise Exception("Array dimensions mismatch: %s" %(i))
                ST.insert_in_sym_table(idName=i, idType=p[1]['type'], is_array=True, arr_size=0)
    for symbol in p[2]:
        if "emit_intrs" in symbol.keys():
            for X in symbol["emit_intrs"]:
                TAC.emit(X[0], X[1], X[2], X[3], ST)
    rules_store.append(p.slice)

def p_Statement(p):
    '''
    Statement : StatementWithoutTrailingSubstatement
    | LabeledStatement
    | IfThenStatement
    | IfThenElseStatement
    | WhileStatement
    | ForStatement
    '''
    p[0] = p[1]
    rules_store.append(p.slice)

def p_StatementNoShortIf(p):
    '''
    StatementNoShortIf : StatementWithoutTrailingSubstatement
    | LabeledStatementNoShortIf
    | IfThenElseStatementNoShortIf
    | WhileStatementNoShortIf
    | ForStatementNoShortIf
    '''
    p[0] = p[1]
    rules_store.append(p.slice)

def p_StatementWithoutTrailingSubstatement(p):
    '''
    StatementWithoutTrailingSubstatement : Block
    | EmptyStatement
    | ExpressionStatement
    | SwitchStatement
    | DoStatement
    | BreakStatement
    | ContinueStatement
    | ReturnStatement
    | ThrowStatement
    | TryStatement
    '''
    p[0] = p[1]
    rules_store.append(p.slice)

def p_EmptyStatement(p):
    '''
    EmptyStatement : STMT_TERMINATOR
    '''
    rules_store.append(p.slice)

def p_LabeledStatement(p):
    '''
    LabeledStatement : Identifier COLON Statement
    '''
    rules_store.append(p.slice)

def p_LabeledStatementNoShortIf(p):
    '''
    LabeledStatementNoShortIf : Identifier COLON StatementNoShortIf
    '''
    rules_store.append(p.slice)

def p_ExpressionStatement(p):
    '''
    ExpressionStatement : StatementExpression STMT_TERMINATOR
    '''
    p[0] = p[1]
    rules_store.append(p.slice)

def p_StatementExpression(p):
    '''
    StatementExpression : Assignment
    | PreIncrementExpression
    | PreDecrementExpression
    | PostIncrementExpression
    | PostDecrementExpression
    | MethodInvocation
    | ClassInstanceCreationExpression
    '''
    p[0] = p[1]
    rules_store.append(p.slice)

def p_IfThenStatement(p):
    '''
    IfThenStatement : IF L_PAREN Expression R_PAREN IfMark1 Statement IfMark2
    '''
    rules_store.append(p.slice)

def p_IfThenElseStatement(p):
    '''
    IfThenElseStatement : IF L_PAREN Expression R_PAREN IfMark1 StatementNoShortIf IfMark5 ELSE IfMark3 Statement IfMark4
    '''
    rules_store.append(p.slice)

def p_IfThenElseStatementNoShortIf(p):
    '''
    IfThenElseStatementNoShortIf : IF L_PAREN Expression R_PAREN IfMark1 StatementNoShortIf IfMark5 ELSE IfMark3 StatementNoShortIf IfMark4
    '''
    rules_store.append(p.slice)

def p_IfMark1(p):
    ''' IfMark1 : '''
    l1 = ST.make_label()
    l2 = ST.make_label()
    TAC.emit('ifgoto', p[-2]['place'], 'eq 0', l2, ST)
    TAC.emit('goto', l1, '', '', ST)
    TAC.emit('label', l1, '', '', ST)
    ST.create_new_table(l1, TAC)
    p[0] = [l1, l2]

def p_IfMark2(p):
    ''' IfMark2 : '''
    ST.end_scope(TAC)
    TAC.emit('label', p[-2][1], '', '', ST)

def p_IfMark3(p):
    ''' IfMark3 : '''
    l3 = ST.make_label()
    TAC.emit('goto', l3, '', '', ST)
    TAC.emit('label', p[-4][1], '', '', ST)
    ST.create_new_table(p[-4][1], TAC)
    p[0] = [l3]

def p_IfMark4(p):
    ''' IfMark4 : '''
    ST.end_scope(TAC)
    TAC.emit('label', p[-2][0], '', '', ST)

def p_IfMark5(p):
    ''' IfMark5 : '''
    ST.end_scope(TAC)

def p_SwitchStatement(p):
    '''
    SwitchStatement : SWITCH L_PAREN Expression R_PAREN SwMark2 SwitchBlock SwMark3
    '''
    if not p[3]['type'] == 'INT':
        raise Exception("Switch clause only supports Integer types")
    rules_store.append(p.slice)

def p_SwMark2(p):
    ''' SwMark2 : '''
    l1 = ST.make_label()
    l2 = ST.make_label()
    stackend.append(l1)
    TAC.emit('goto', l2, '', '', ST)
    ST.create_new_table(l2, TAC)
    p[0] = [l1, l2]

def p_SwMark3(p):
    ''' SwMark3 : '''
    TAC.emit('goto', p[-2][0], '', '', ST)
    TAC.emit('label', p[-2][1], '', '', ST)
    for i in range(len(p[-1]['labels'])):
        label = p[-1]['labels'][i]
        exp = p[-1]['expressions'][i]
        if exp == '':
            TAC.emit('goto', label, '', '', ST)
        else:
            TAC.emit('ifgoto', p[-4]['place'], 'eq ' + exp, label, ST)
    TAC.emit('label', p[-2][0], '', '', ST)
    ST.end_scope(TAC)

def p_SwitchBlock(p):
    '''
    SwitchBlock : BLOCK_OPENER BLOCK_CLOSER
    | BLOCK_OPENER SwitchBlockStatementGroups BLOCK_CLOSER
    '''
    p[0] = p[2]
    rules_store.append(p.slice)

def p_SwitchBlockStatementGroups(p):
    '''
    SwitchBlockStatementGroups : SwitchBlockStatementGroup
    | SwitchBlockStatementGroups SwitchBlockStatementGroup
    '''
    p[0] = {
        'expressions' : [],
        'labels' : []
    }
    if len(p) == 2:
        p[0]['expressions'].append(p[1]['expression'])
        p[0]['labels'].append(p[1]['label'])
    else:
        p[0]['expressions'] = p[1]['expressions'] + [p[2]['expression']]
        p[0]['labels'] = p[1]['labels'] + [p[2]['label']]
    rules_store.append(p.slice)

def p_SwitchBlockStatementGroup(p):
    '''
    SwitchBlockStatementGroup : SwitchLabel BlockStatements
    '''
    p[0] = p[1]
    rules_store.append(p.slice)

def p_SwitchLabel(p):
    '''
    SwitchLabel : SwMark1 CASE ConstantExpression COLON
    | SwMark1 DEFAULT COLON
    '''
    p[0] = {}
    if len(p) == 5:
        if not p[3]['type'] == 'INT':
            raise Exception("Only Integers allowed for case comparisions")
        p[0]['expression'] = p[3]['place']
    else:
        p[0]['expression'] = ''
    p[0]['label'] = p[1]
    rules_store.append(p.slice)

def p_SwMark1(p):
    ''' SwMark1 : '''
    l = ST.make_label()
    TAC.emit('label', l, '', '', ST)
    p[0] = l

def p_WhileStatement(p):
    '''
    WhileStatement : WHILE WhMark1 L_PAREN Expression R_PAREN WhMark2 Statement WhMark3
    '''
    rules_store.append(p.slice)

def p_WhileStatementNoShortIf(p):
    '''
    WhileStatementNoShortIf : WHILE WhMark1 L_PAREN Expression R_PAREN WhMark2 StatementNoShortIf WhMark3
    '''
    rules_store.append(p.slice)

def p_WhMark1(p):
    '''WhMark1 : '''
    l1 = ST.make_label()
    l2 = ST.make_label()
    l3 = ST.make_label()
    stackbegin.append(l1)
    stackend.append(l3)
    ST.create_new_table(l1, TAC)
    TAC.emit('label',l1,'','', ST)
    p[0]=[l1,l2,l3]

def p_WhMark2(p):
    '''WhMark2 : '''
    TAC.emit('ifgoto',p[-2]['place'],'eq 0', p[-4][2], ST)
    TAC.emit('goto',p[-4][1],'','', ST)
    TAC.emit('label',p[-4][1],'','', ST)

def p_WhMark3(p):
    '''WhMark3 : '''
    TAC.emit('goto',p[-6][0],'','', ST)
    TAC.emit('label',p[-6][2],'','', ST)
    ST.end_scope(TAC)
    stackbegin.pop()
    stackend.pop()

def p_DoStatement(p):
    '''
    DoStatement : DO doWhMark1 Statement WHILE doWhMark2 L_PAREN Expression R_PAREN doWhMark3 STMT_TERMINATOR
    '''
    rules_store.append(p.slice)

def p_doWhMark1(p):
    '''doWhMark1 : '''
    l1 = ST.make_label()
    l2 = ST.make_label()
    l3 = ST.make_label()
    stackbegin.append(l1)
    stackend.append(l3)
    ST.create_new_table(l1, TAC)
    TAC.emit('label',l1,'','', ST)
    p[0]=[l1,l2,l3]

def p_doWhMark3(p):
    '''doWhMark3 : '''
    TAC.emit('ifgoto',p[-2]['place'],'eq 0', p[-7][2], ST)
    TAC.emit('goto',p[-7][0],'','', ST)
    TAC.emit('label',p[-7][2],'','', ST)

def p_doWhMark2(p):
    '''doWhMark2 : '''
    #TAC.emit('goto',p[-3][1],'','', ST)
    TAC.emit('label',p[-3][1],'','', ST)
    ST.end_scope(TAC)
    stackbegin.pop()
    stackend.pop()

def p_ForStatement(p):
    '''
    ForStatement : FOR FoMark0 L_PAREN ForInit STMT_TERMINATOR FoMark1 Expression STMT_TERMINATOR FoMark6 ForUpdate R_PAREN FoMark2 Statement FoMark3
    | FOR FoMark0 L_PAREN STMT_TERMINATOR FoMark1 Expression STMT_TERMINATOR FoMark6 ForUpdate R_PAREN FoMark2 Statement FoMark3
    | FOR FoMark0 L_PAREN ForInit STMT_TERMINATOR FoMark1 STMT_TERMINATOR FoMark6 ForUpdate R_PAREN FoMark2 Statement FoMark3
    | FOR FoMark0 L_PAREN ForInit STMT_TERMINATOR FoMark1 Expression STMT_TERMINATOR R_PAREN FoMark4 Statement FoMark5
    | FOR FoMark0 L_PAREN ForInit STMT_TERMINATOR FoMark1 STMT_TERMINATOR R_PAREN FoMark4 Statement FoMark5
    | FOR FoMark0 L_PAREN STMT_TERMINATOR FoMark1 Expression STMT_TERMINATOR R_PAREN FoMark4 Statement FoMark5
    | FOR FoMark0 L_PAREN STMT_TERMINATOR FoMark1 STMT_TERMINATOR FoMark6 ForUpdate R_PAREN FoMark2 Statement FoMark3
    | FOR FoMark0 L_PAREN STMT_TERMINATOR FoMark1 STMT_TERMINATOR R_PAREN FoMark4 Statement FoMark5
    '''
    rules_store.append(p.slice)

def p_ForStatementNoShortIf(p):
    '''
    ForStatementNoShortIf : FOR FoMark0 L_PAREN ForInit STMT_TERMINATOR FoMark1 Expression STMT_TERMINATOR FoMark6 ForUpdate R_PAREN FoMark2 StatementNoShortIf FoMark3
    | FOR FoMark0 L_PAREN STMT_TERMINATOR FoMark1 Expression STMT_TERMINATOR FoMark6 ForUpdate R_PAREN FoMark2 StatementNoShortIf FoMark3
    | FOR FoMark0 L_PAREN ForInit STMT_TERMINATOR FoMark1 STMT_TERMINATOR FoMark6 ForUpdate R_PAREN FoMark2 StatementNoShortIf FoMark3
    | FOR FoMark0 L_PAREN ForInit STMT_TERMINATOR FoMark1 Expression STMT_TERMINATOR R_PAREN FoMark4 StatementNoShortIf FoMark5
    | FOR FoMark0 L_PAREN ForInit STMT_TERMINATOR FoMark1 STMT_TERMINATOR R_PAREN FoMark4 StatementNoShortIf FoMark5
    | FOR FoMark0 L_PAREN STMT_TERMINATOR FoMark1 Expression STMT_TERMINATOR R_PAREN FoMark4 StatementNoShortIf FoMark5
    | FOR FoMark0 L_PAREN STMT_TERMINATOR FoMark1 STMT_TERMINATOR FoMark6 ForUpdate R_PAREN FoMark2 StatementNoShortIf FoMark3
    | FOR FoMark0 L_PAREN STMT_TERMINATOR FoMark1 STMT_TERMINATOR R_PAREN FoMark4 StatementNoShortIf FoMark5
    '''
    rules_store.append(p.slice)

def p_FoMark0(p):
    '''FoMark0 : '''
    l0 = ST.make_label()
    ST.create_new_table(l0, TAC)

def p_FoMark1(p):
    '''FoMark1 : '''
    l1 = ST.make_label()
    l2 = ST.make_label()
    l3 = ST.make_label()
    l4 = ST.make_label()
    stackbegin.append(l1)
    stackend.append(l3)
    TAC.emit('label',l1,'','', ST)
    p[0]=[l1,l2,l3, l4]

def p_FoMark2(p):
    '''FoMark2 : '''
    TAC.emit('goto', p[-6][0],'','', ST)
    TAC.emit('label', p[-6][1],'','', ST)
    TAC.emit('ifgoto',p[-5]['place'],'eq 0', p[-6][3], ST)
    # TAC.emit('goto',p[-5][1],'','', ST)
    # TAC.emit('label',p[-5][1],'','', ST)

def p_FoMark6(p):
    '''FoMark6 : '''
    TAC.emit('goto', p[-3][1],'','', ST)
    TAC.emit('label',p[-3][2],'','', ST)

def p_FoMark4(p):
    '''FoMark4 : '''
    TAC.emit('ifgoto',p[-3]['place'],'eq 0', p[-4][2], ST)
    TAC.emit('goto',p[-4][1],'','', ST)
    TAC.emit('label',p[-4][1],'','', ST)

def p_FoMark3(p):
    '''FoMark3 : '''
    TAC.emit('goto', p[-8][2],'', '', ST)
    TAC.emit('label', p[-8][3],'', '', ST)
    # TAC.emit('goto',p[-7][0] + '--**--','','', ST)
    # TAC.emit('label',p[-7][2],'','', ST)
    ST.end_scope(TAC)
    stackbegin.pop()
    stackend.pop()

def p_FoMark5(p):
    '''FoMark5 : '''
    TAC.emit('goto',p[-6][0],'','', ST)
    TAC.emit('label',p[-6][2],'','', ST)
    ST.end_scope(TAC)
    stackbegin.pop()
    stackend.pop()

def p_ForInit(p):
    '''
    ForInit : StatementExpressionList
    | LocalVariableDeclaration
    '''
    rules_store.append(p.slice)

def p_ForUpdate(p):
    '''
    ForUpdate : StatementExpressionList
    '''
    rules_store.append(p.slice)

def p_StatementExpressionList(p):
    '''
    StatementExpressionList : StatementExpression
    | StatementExpressionList COMMA StatementExpression
    '''
    rules_store.append(p.slice)

def p_BreakStatement(p):
    '''
    BreakStatement : BREAK Identifier STMT_TERMINATOR
    | BREAK STMT_TERMINATOR
    '''
    if(len(p)==3 and p[1]=='break'):
        TAC.emit('goto', stackend[-1], '', '', ST)
    rules_store.append(p.slice)

def p_ContinueStatement(p):
    '''
    ContinueStatement : CONTINUE Identifier STMT_TERMINATOR
    | CONTINUE STMT_TERMINATOR
    '''
    if(len(p)==3 and p[1]=='continue'):
        TAC.emit('goto', stackbegin[-1], '', '', ST)
    rules_store.append(p.slice)

def p_ReturnStatement(p):
    '''
    ReturnStatement : RETURN Expression STMT_TERMINATOR
    | RETURN STMT_TERMINATOR
    '''
    if(len(p)==3 and p[1]=='return'):
        TAC.emit('ret', '', '', '', ST)
    else:
        # to_return = ST.lookup(ST.curr_scope, is_func=True)['ret_type']
        to_return = global_return_type
        curr_returned = ST.lookup(p[2]['place'])
        if curr_returned != None:
            if to_return[0] != curr_returned['type']:
                raise Exception("Wrong return type in %s" %(ST.curr_scope))
            if 'is_array' in curr_returned.keys() and curr_returned['is_array'] and len(curr_returned['arr_size']) != to_return[1]:
                raise Exception("Dimension mismatch in return statement in %s" %(ST.curr_scope))
        elif curr_returned == None:
            if p[2]['type'] != to_return[0] or to_return[1] != 0:
                raise Exception("Wrong return type in %s" %(ST.curr_scope))
        TAC.emit('ret', p[2]['place'], '', '', ST)
    rules_store.append(p.slice)

def p_ThrowStatement(p):
    '''
    ThrowStatement : THROW Expression STMT_TERMINATOR
    '''
    rules_store.append(p.slice)

def p_TryStatement(p):
    '''
    TryStatement : TRY Block Catches
    | TRY Block Catches Finally
    | TRY Block Finally
    '''
    rules_store.append(p.slice)

def p_Catches(p):
    '''
    Catches : CatchClause
    | Catches CatchClause
    '''
    rules_store.append(p.slice)

def p_CatchClause(p):
    '''
    CatchClause : CATCH L_PAREN FormalParameter R_PAREN Block
    '''
    rules_store.append(p.slice)

def p_Finally(p):
    '''
    Finally : FINALLY Block
    '''
    rules_store.append(p.slice)

# Section 19.12
def p_Primary(p):
    '''
    Primary : PrimaryNoNewArray
    | ArrayCreationExpression
    '''
    p[0] = p[1]
    rules_store.append(p.slice)

def p_PrimaryNoNewArray(p):
    '''
    PrimaryNoNewArray : Literal
    | THIS
    | L_PAREN Expression R_PAREN
    | ClassInstanceCreationExpression
    | FieldAccess
    | MethodInvocation
    | ArrayAccess
    '''
    if len(p) == 2:
        p[0] = p[1]
    else:
        p[0] = p[2]
    rules_store.append(p.slice)

def p_ClassInstanceCreationExpression(p):
    '''
    ClassInstanceCreationExpression : NEW ClassType L_PAREN R_PAREN
    | NEW ClassType L_PAREN ArgumentList R_PAREN
    '''
    attributes = class_table[p[2]['place']]
    p[0] = attributes
    #TAC.emit("declare","_"+"obj_","","",ST)
    rules_store.append(p.slice)

def p_ArgumentList(p):
    '''
    ArgumentList : Expression
    | ArgumentList COMMA Expression
    '''
    if len(p) == 2:
        p[0] = [p[1]]
    else:
        p[0] = p[1] + [p[3]]
    rules_store.append(p.slice)

def p_ArrayCreationExpression(p):
    '''
    ArrayCreationExpression : NEW PrimitiveType DimExprs
    | NEW ClassType DimExprs
    '''
    if len(p) == 4:
        p[0] = {
            'type' : p[2]['type'],
            'arr_size' : p[3],
            'is_array' : True,
        }
    rules_store.append(p.slice)

def p_DimExprs(p):
    '''
    DimExprs : DimExpr
    | DimExprs DimExpr
    '''
    if len(p) == 2:
        p[0] = [p[1]]
    else:
        p[0] = p[1] + [p[2]]
    rules_store.append(p.slice)

def p_DimExpr(p):
    '''
    DimExpr : L_SQBR Expression R_SQBR
    '''
    if p[2]['type'] == 'INT':
        p[0] = p[2]['place']
    else:
        raise Exception("Array declaration requires a size as integer : " + p[2]['place'])
    rules_store.append(p.slice)

def p_Dims(p):
    '''
    Dims : L_SQBR R_SQBR
    | Dims L_SQBR R_SQBR
    '''
    if len(p) == 3:
        p[0] = 1
    else:
        p[0] = 1 + p[1]
    rules_store.append(p.slice)

def p_FieldAccess(p):
    '''
    FieldAccess : Primary DOT Identifier
    | SUPER DOT Identifier
    '''
    p[0] = {}
    index = -1
    for i, var in enumerate(g.members):
        if var[0] == p[3]:
            index = i
            break
    if index == -1:
        raise Exception('Not in scope')
    # TAC.emit('this[' + str(index) + ']', p[3], '', p[2], ST)

    t1 = ST.get_temp_var()
    t2 = ST.get_temp_var()
    TAC.emit(t2, str(index), '', '=', ST)
    src = 'this' + '[' + t2 + ']'
    TAC.emit(t1, src, '', '=', ST)

    p[0]['type'] = 'INT'
    p[0]['place'] = t1
    p[0]['access_type'] = 'array'
    p[0]['name'] = 'this'
    p[0]['index'] = t2
    rules_store.append(p.slice)

def p_MethodInvocation(p):
    '''
    MethodInvocation : Name L_PAREN ArgumentList R_PAREN
    | Name L_PAREN R_PAREN
    | Primary DOT Identifier L_PAREN ArgumentList R_PAREN
    | Primary DOT Identifier L_PAREN R_PAREN
    | SUPER DOT Identifier L_PAREN ArgumentList R_PAREN
    | SUPER DOT Identifier L_PAREN R_PAREN
    '''
    # Check return type of function in symbol table
    if p[2] == '(':
        if p[1]['place'] not in g.func_members and 'this' not in p[1].keys() and p[1]['place'] != 'println' and p[1]['place'] != 'input':
            raise Exception("Method not defined")
        attributes = ST.lookup(p[1]['place'], is_func=True)
        if attributes == None and p[1]['place'] != "println" and p[1]['place'] != "input":
            raise Exception("Undeclared function used: %s" %(p[1]['place']))

        if p[1]['place'] == 'println':
            if len(p) == 5:
                for parameter in p[3]:
                    if 'type' in parameter.keys():
                        TAC.emit('print',parameter['place'],'','_' + parameter['type'], ST)
                    else:
                        TAC.emit('print', parameter['place'], '', '_INT', ST)
        elif p[1]['place'] == 'input':
            if len(p) == 5:
                for parameter in p[3]:
                    if parameter['type'] != 'INT':
                        raise Exception("Input only INT")
                    TAC.emit('input',parameter['place'],'','', ST)
        else:
            temp_var = ST.get_temp_var()
            if len(p) == 5:
                prototype = attributes['params']
                if len(prototype) != len(p[3]):
                    raise Exception("Wrong number of arguments to function call: %s" %(p[1]['place']))
                if 'this' in p[1].keys():
                    TAC.emit('param', p[1]['this'], '', '', ST)
                for i in range(len(p[3])):
                    parameter = p[3][i]
                    proto = prototype[i]
                    if parameter['type'] != proto['type']:
                        raise Exception("Wrong type of arg passed to function %s; got %s but expected %s" %(p[1]['place'], parameter['type'], proto['type']))
                    TAC.emit('param',parameter['place'],'','', ST)
            else:
                if 'this' in p[1].keys():
                    TAC.emit('param', p[1]['this'], '', '', ST)
            TAC.emit('call',p[1]['place'],temp_var,len(p[3]), ST)
            p[0] = {
                'place' : temp_var,
                'ret_type' : attributes['ret_type']
            }
    rules_store.append(p.slice)

def p_ArrayAccess(p):
    '''
    ArrayAccess : Name DimExprs
    '''
    p[0] = {}
    attributes = ST.lookup(p[1]['place'])
    if attributes == None:
        raise Exception("Undeclared Symbol Used: %s" %(p[1]['place']))
    if not 'is_array' in attributes or not attributes['is_array']:
        raise Exception("Only array type can be indexed : %s" %(p[1]['place']))

    indexes = p[2]
    if not len(indexes) == len(attributes['arr_size']):
        raise Exception("Not a valid indexing for array %s" %(p[1]['place']))

    arr_size = attributes['arr_size']
    address_indices = p[2]
    t2 = ST.get_temp_var()
    TAC.emit(t2, address_indices[0], '', '=', ST)
    for i in range(1, len(address_indices)):
        TAC.emit(t2, t2, arr_size[i], '*', ST)
        TAC.emit(t2, t2, address_indices[i], '+', ST)
    index = t2

    src = p[1]['place'] + '[' + str(index) + ']'
    t1 = ST.get_temp_var()
    TAC.emit(t1, src, '', '=', ST)

    p[0]['type'] = attributes['type']
    p[0]['place'] = t1
    p[0]['access_type'] = 'array'
    p[0]['name'] = p[1]['place']
    p[0]['index'] = str(index)

    rules_store.append(p.slice)

def p_PostfixExpression(p):
    '''
    PostfixExpression : Primary
    | Name
    | PostIncrementExpression
    | PostDecrementExpression
    '''
    if 'fields' in p[1].keys():
        p[0] = p[1]
        return
    p[0] = {}
    if 'idVal' in p[1].keys():
        p[0]['place'] = p[1]['idVal']
        p[0]['type'] = p[1]['type']
        p[0]['is_var'] = False

    elif 'place' in p[1].keys() and 'is_var' in p[1].keys() and p[1]['is_var']:
        attributes = ST.lookup(p[1]['place'])
        if attributes == None:
            raise Exception("Undeclared Variable Used: %s" %(p[1]['place']))
        else:
            p[0]['type'] = attributes['type']
            p[0]['place'] = p[1]['place']

    elif 'place' in p[1].keys():
        p[0] = p[1]

    elif 'name' in p[1].keys() and p[1]['name'].find('_obj_') != -1:
        p[0]['type'] = p[1]['type']
        p[0]['place'] = ST.get_temp_var()
        p[0]['access_type'] = 'array'
        p[0]['name'] = p[1]['name']
        p[0]['index'] = p[1]['index']

        TAC.emit(p[0]['place'], p[0]['name'] + '[' + p[0]['index'] + ']', '', '=', ST)

    elif 'is_array' in p[1].keys():
        p[0]['place'] = p[1]['arr_size']
        p[0]['type'] = p[1]['type']
        p[0]['is_array'] = True
    rules_store.append(p.slice)

def p_PostIncrementExpression(p):
    '''
    PostIncrementExpression : PostfixExpression INCREMENT
    '''
    if p[1]['type'] == 'INT':
        TAC.emit(p[1]['place'], p[1]['place'], '1', '+', ST)
        p[0] = {
            'place' : p[1]['place'],
            'type' : 'INT'
        }
    else:
        raise Exception("Error: increment operator can be used with integers only")
    rules_store.append(p.slice)

def p_PostDecrementExpression(p):
    '''
    PostDecrementExpression : PostfixExpression DECREMENT
    '''
    if p[1]['type'] == 'INT':
        TAC.emit(p[1]['place'], p[1]['place'], '1', '-', ST)
        p[0] = {
            'place' : p[1]['place'],
            'type' : 'INT'
        }
    else:
        raise Exception("Error: decrement operator can be used with integers only")
    rules_store.append(p.slice)

def p_UnaryExpression(p):
    '''
    UnaryExpression : PreIncrementExpression
    | PreDecrementExpression
    | PLUS UnaryExpression
    | MINUS UnaryExpression
    | UnaryExpressionNotPlusMinus
    '''
    if len(p) == 2:
        p[0] = p[1]
        return
    else:
        pass
    rules_store.append(p.slice)

# Checked
def p_PreIncrementExpression(p):
    '''
    PreIncrementExpression : INCREMENT UnaryExpression
    '''
    if(p[2]['type'] == 'INT'):
        TAC.emit(p[2]['place'],p[2]['place'],'1','+', ST)
        p[0] = {
            'place' : p[2]['place'],
            'type' : 'INT'
        }
    else:
        raise Exception("Error: increment operator can be used with integers only")

    rules_store.append(p.slice)

# Checked
def p_PreDecrementExpression(p):
    '''
    PreDecrementExpression : DECREMENT UnaryExpression
    '''
    if(p[2]['type']=='INT'):
        TAC.emit(p[2]['place'],p[2]['place'],'1','-', ST)
        p[0] = {
            'place' : p[2]['place'],
            'type' : 'INT'
        }
    else:
        raise Exception("Error: decrement operator can be used with integers only")
    rules_store.append(p.slice)

def p_UnaryExpressionNotPlusMinus(p):
    '''
    UnaryExpressionNotPlusMinus : PostfixExpression
    | BITWISE_NOT UnaryExpression
    | LOGICAL_NOT UnaryExpression
    | CastExpression
    '''
    if len(p) == 2:
        p[0] = p[1]
    else:
        t = ST.get_temp_var()
        TAC.emit(t, p[2]['place'], '', p[1], ST)
        p[0] = p[2]
        p[0]['place'] = t
    rules_store.append(p.slice)

def p_CastExpression(p):
    '''
    CastExpression : L_PAREN PrimitiveType Dims R_PAREN UnaryExpression
    | L_PAREN PrimitiveType R_PAREN UnaryExpression
    | L_PAREN Expression R_PAREN UnaryExpressionNotPlusMinus
    | L_PAREN Name Dims R_PAREN UnaryExpressionNotPlusMinus
    '''
    rules_store.append(p.slice)

# Checked
def p_MultiplicativeExpression(p):
    '''
    MultiplicativeExpression : UnaryExpression
    | MultiplicativeExpression MULT UnaryExpression
    | MultiplicativeExpression DIVIDE UnaryExpression
    | MultiplicativeExpression MODULO UnaryExpression
    '''
    if(len(p)==2):
        p[0] = p[1]
        return
    newPlace = ST.get_temp_var()
    p[0] = {
        'place' : newPlace,
    }
    # -----------------------------
    if 'ret_type' in p[1].keys():
        type1 = p[1]['ret_type'][0]
        if p[1]['ret_type'][1] != 0:
            raise Exception("Error")
    else:
        type1 = p[1]['type']

    if 'ret_type' in p[3].keys():
        type2 = p[3]['ret_type'][0]
        if p[3]['ret_type'][1] != 0:
            raise Exception("Error")
    else:
        type2 = p[3]['type']
    # -----------------------------
    if p[2] == '*':
        if type1 == "INT" and type2 == "INT":
            TAC.emit(newPlace,p[1]['place'], p[3]['place'], p[2], ST)
            p[0]['type'] = 'INT'
        else:
            raise Exception('Error: Type is not compatible'+p[1]['place']+','+p[3]['place']+'.')
    elif p[2] == '/' :
        if type1 == "INT" and type2 == "INT":
            TAC.emit(newPlace, p[1]['place'], p[3]['place'], p[2], ST)
            p[0]['type'] = 'INT'
        else:
            raise Exception('Error: Type is not compatible' + p[1]['place'] + ',' + p[3]['place'] + '.')
    elif p[2] == '%':
        if type1 == "INT" and type2 == "INT":
            TAC.emit(newPlace,p[1]['place'],p[3]['place'],p[2], ST)
            p[0]['type'] = 'INT'
        else:
            raise Exception('Error: Type is not compatible' + p[1]['place'] + ',' + p[3]['place'] + '.')
    rules_store.append(p.slice)

# Checked
def p_AdditiveExpression(p):
    '''
    AdditiveExpression : MultiplicativeExpression
    | AdditiveExpression PLUS MultiplicativeExpression
    | AdditiveExpression MINUS MultiplicativeExpression
    '''
    if len(p) == 2:
        p[0] = p[1]
        return
    newPlace = ST.get_temp_var()
    p[0] = {
        'place' : newPlace,
    }

    if 'ret_type' in p[1].keys():
        type1 = p[1]['ret_type'][0]
        if p[1]['ret_type'][1] != 0:
            raise Exception("Error")
    else:
        type1 = p[1]['type']

    if 'ret_type' in p[3].keys():
        type2 = p[3]['ret_type'][0]
        if p[3]['ret_type'][1] != 0:
            raise Exception("Error")
    else:
        type2 = p[3]['type']

    if type1 == "INT" and type2 == "INT":
        TAC.emit(newPlace, p[1]['place'], p[3]['place'], p[2], ST)
        p[0]['type'] = 'INT'
    elif type1 == "CHAR" and type2 == "INT":
        TAC.emit(newPlace, p[1]['place'], p[3]['place'], p[2], ST)
        p[0]['type'] = 'CHAR'
    elif type1 == "INT" and type2 == "CHAR":
        TAC.emit(newPlace, p[1]['place'], p[3]['place'], p[2], ST)
        p[0]['type'] = 'CHAR'
    elif type1 == "CHAR" and type2 == "CHAR":
        TAC.emit(newPlace, p[1]['place'], p[3]['place'], p[2], ST)
        p[0]['type'] = 'CHAR'
    else:
        raise Exception("Error: integer value is needed")
    rules_store.append(p.slice)

# Checked
def p_ShiftExpression(p):
    '''
    ShiftExpression : AdditiveExpression
    | ShiftExpression L_SHIFT AdditiveExpression
    | ShiftExpression R_SHIFT AdditiveExpression
    '''
    if len(p) == 2:
        p[0] = p[1]
        return

    newPlace = ST.get_temp_var()
    p[0] = {
        'place' : newPlace,
    }
    if 'ret_type' in p[1].keys():
        type1 = p[1]['ret_type'][0]
        if p[1]['ret_type'][1] != 0:
            raise Exception("Error")
    else:
        type1 = p[1]['type']

    if 'ret_type' in p[3].keys():
        type2 = p[3]['ret_type'][0]
        if p[3]['ret_type'][1] != 0:
            raise Exception("Error")
    else:
        type2 = p[3]['type']

    if type1 == "INT" and type2 == "INT":
        TAC.emit(newPlace, p[1]['place'], p[3]['place'], p[2], ST)
        p[0]['type'] = 'INT'
    else:
        raise Exception("Error: integer value is needed")

    rules_store.append(p.slice)

# Checked
def p_RelationalExpression(p):
    '''
    RelationalExpression : ShiftExpression
    | RelationalExpression LST ShiftExpression
    | RelationalExpression GRT ShiftExpression
    | RelationalExpression LEQ ShiftExpression
    | RelationalExpression GEQ ShiftExpression
    | RelationalExpression INSTANCEOF ReferenceType
    '''
    if len(p) == 2:
        p[0] = p[1]
        return
    l1 = ST.make_label()
    l2 = ST.make_label()
    l3 = ST.make_label()
    newPlace = ST.get_temp_var()
    p[0] = {
        'place' : newPlace,
    }

    if 'ret_type' in p[1].keys():
        type1 = p[1]['ret_type'][0]
        if p[1]['ret_type'][1] != 0:
            raise Exception("Error")
    else:
        type1 = p[1]['type']

    if 'ret_type' in p[3].keys():
        type2 = p[3]['ret_type'][0]
        if p[3]['ret_type'][1] != 0:
            raise Exception("Error")
    else:
        type2 = p[3]['type']

    if type1 == "INT" and type2 == "INT":
        if p[2]=='>':
            TAC.emit('ifgoto', p[1]['place'], 'gt ' + p[3]['place'], l2, ST)
            TAC.emit('label', l1, '', '', ST)
            TAC.emit(newPlace, '0', '', '=', ST)
            TAC.emit('goto', l3, '', '', ST)
            TAC.emit('label', l2, '', '', ST)
            TAC.emit(newPlace, '1', '', '=', ST)
            TAC.emit('label', l3, '', '', ST)
            p[0]['type'] = 'INT'
        elif p[2]=='>=':
            TAC.emit('ifgoto', p[1]['place'], 'geq ' + p[3]['place'], l2, ST)
            TAC.emit('label', l1, '', '', ST)
            TAC.emit(newPlace, '0', '', '=', ST)
            TAC.emit('goto', l3, '', '', ST)
            TAC.emit('label', l2, '', '', ST)
            TAC.emit(newPlace, '1', '', '=', ST)
            TAC.emit('label', l3, '', '', ST)
            p[0]['type'] = 'INT'
        elif p[2]=='<':
            TAC.emit('ifgoto', p[1]['place'], 'lt ' + p[3]['place'], l2, ST)
            TAC.emit('label', l1, '', '', ST)
            TAC.emit(newPlace, '0', '', '=', ST)
            TAC.emit('goto', l3, '', '', ST)
            TAC.emit('label', l2, '', '', ST)
            TAC.emit(newPlace, '1', '', '=', ST)
            TAC.emit('label', l3, '', '', ST)
            p[0]['type'] = 'INT'
        elif p[2]=='<=':
            TAC.emit('ifgoto', p[1]['place'], 'leq ' + p[3]['place'], l2, ST)
            TAC.emit('label', l1, '', '', ST)
            TAC.emit(newPlace, '0', '', '=', ST)
            TAC.emit('goto', l3, '', '', ST)
            TAC.emit('label', l2, '', '', ST)
            TAC.emit(newPlace, '1', '', '=', ST)
            TAC.emit('label', l3, '', '', ST)
            p[0]['type'] = 'INT'
    else:
        raise Exception('Error: Type is not compatible' + p[1]['place'] + ',' + p[3]['place'] + '.')
    rules_store.append(p.slice)

# Checked
def p_EqualityExpression(p):
    '''
    EqualityExpression : RelationalExpression
    | EqualityExpression EQUALS RelationalExpression
    | EqualityExpression NOT_EQUAL RelationalExpression
    '''
    if(len(p)==2):
        p[0] = p[1]
        return
    l1 = ST.make_label()
    l2 = ST.make_label()
    l3 = ST.make_label()
    newPlace = ST.get_temp_var()
    p[0]={
        'place' : newPlace,
    }
    if 'ret_type' in p[1].keys():
        type1 = p[1]['ret_type'][0]
        if p[1]['ret_type'][1] != 0:
            raise Exception("Error")
    else:
        type1 = p[1]['type']

    if 'ret_type' in p[3].keys():
        type2 = p[3]['ret_type'][0]
        if p[3]['ret_type'][1] != 0:
            raise Exception("Error")
    else:
        type2 = p[3]['type']

    if type1 == "INT" and type2 == "INT":
        if(p[2][0]=='='):
            TAC.emit('ifgoto', p[1]['place'], 'eq ' + p[3]['place'], l2, ST)
            TAC.emit('label', l1, '', '', ST)
            TAC.emit(newPlace, '0', '', '=', ST)
            TAC.emit('goto', l3, '', '', ST)
            TAC.emit('label', l2, '', '', ST)
            TAC.emit(newPlace, '1', '', '=', ST)
            TAC.emit('label', l3, '', '', ST)
            p[0]['type'] = 'INT'
        else:
            TAC.emit('ifgoto', p[1]['place'], 'neq '+ p[3]['place'], l2, ST)
            TAC.emit('label', l1, '', '', ST)
            TAC.emit(newPlace, '0', '', '=', ST)
            TAC.emit('goto', l3, '', '', ST)
            TAC.emit('label', l2, '', '', ST)
            TAC.emit(newPlace, '1', '', '=', ST)
            TAC.emit('label', l3, '', '', ST)
            p[0]['type'] = 'INT'
    else:
        raise Exception('Only INT type comparisions supported: ' + p[1]['place'] + ' and' + p[3]['place'])
    rules_store.append(p.slice)

def p_AndExpression(p):
    '''
    AndExpression : EqualityExpression
    | AndExpression BITWISE_AND EqualityExpression
    '''
    if(len(p)==2):
        p[0] = p[1]
        return
    newPlace = ST.get_temp_var()
    p[0] = {
        'place' : newPlace,
    }
    if 'ret_type' in p[1].keys():
        type1 = p[1]['ret_type'][0]
        if p[1]['ret_type'][1] != 0:
            raise Exception("Error")
    else:
        type1 = p[1]['type']

    if 'ret_type' in p[3].keys():
        type2 = p[3]['ret_type'][0]
        if p[3]['ret_type'][1] != 0:
            raise Exception("Error")
    else:
        type2 = p[3]['type']

    if type1 == "INT" and type2 == "INT":
        TAC.emit(newPlace,p[1]['place'],p[3]['place'],'&', ST)
        p[0]['type'] = 'INT'
    else:
        raise Exception('Error: Type is not compatible' + p[1]['place'] + ',' + p[3]['place'] + '.')
    rules_store.append(p.slice)

def p_ExclusiveOrExpression(p):
    '''
    ExclusiveOrExpression : AndExpression
    | ExclusiveOrExpression BITWISE_XOR AndExpression
    '''
    if(len(p)==2):
        p[0] = p[1]
        return
    newPlace = ST.get_temp_var()
    p[0] = {
        'place' : newPlace,
    }
    if 'ret_type' in p[1].keys():
        type1 = p[1]['ret_type'][0]
        if p[1]['ret_type'][1] != 0:
            raise Exception("Error")
    else:
        type1 = p[1]['type']

    if 'ret_type' in p[3].keys():
        type2 = p[3]['ret_type'][0]
        if p[3]['ret_type'][1] != 0:
            raise Exception("Error")
    else:
        type2 = p[3]['type']

    if type1 == "INT" and type2 == "INT":
        TAC.emit(newPlace,p[1]['place'],p[3]['place'],'^', ST)
        p[0]['type'] = 'INT'
    else:
        raise Exception('Error: Type is not compatible' + p[1]['place'] + ',' + p[3]['place'] + '.')
    rules_store.append(p.slice)

def p_InclusiveOrExpression(p):
    '''
    InclusiveOrExpression : ExclusiveOrExpression
    | InclusiveOrExpression BITWISE_OR ExclusiveOrExpression
    '''
    if(len(p)==2):
        p[0] = p[1]
        return
    newPlace = ST.get_temp_var()
    p[0] = {
        'place' : newPlace,
    }
    if 'ret_type' in p[1].keys():
        type1 = p[1]['ret_type'][0]
        if p[1]['ret_type'][1] != 0:
            raise Exception("Error")
    else:
        type1 = p[1]['type']

    if 'ret_type' in p[3].keys():
        type2 = p[3]['ret_type'][0]
        if p[3]['ret_type'][1] != 0:
            raise Exception("Error")
    else:
        type2 = p[3]['type']

    if type1 == "INT" and type2 == "INT":
        TAC.emit(newPlace, p[1]['place'], p[3]['place'], '|', ST)
        p[0]['type'] = 'INT'
    else:
        raise Exception('Error: Type is not compatible' + p[1]['place'] + ',' + p[3]['place'] + '.')
    rules_store.append(p.slice)

def p_ConditionalAndExpression(p):
    '''
    ConditionalAndExpression : InclusiveOrExpression
    | ConditionalAndExpression LOGICAL_AND InclusiveOrExpression
    '''
    if(len(p)==2):
        p[0] = p[1]
        return
    newPlace = ST.get_temp_var()
    p[0] = {
        'place' : newPlace,
    }
    if 'ret_type' in p[1].keys():
        type1 = p[1]['ret_type'][0]
        if p[1]['ret_type'][1] != 0:
            raise Exception("Error")
    else:
        type1 = p[1]['type']

    if 'ret_type' in p[3].keys():
        type2 = p[3]['ret_type'][0]
        if p[3]['ret_type'][1] != 0:
            raise Exception("Error")
    else:
        type2 = p[3]['type']

    if type1 == "INT" and type2 == "INT":
        l1 = ST.make_label()
        TAC.emit(newPlace,p[1]['place'],'','=', ST)
        TAC.emit('ifgoto',p[1]['place'],'eq 0',l1, ST)
        TAC.emit(newPlace, p[1]['place'], p[3]['place'], '&', ST)
        TAC.emit('label',l1,'','', ST)
        p[0]['type'] = 'INT'
    else:
        raise Exception('Error: Type is not compatible' + p[1]['place'] + ',' + p[3]['place'] + '.')
    rules_store.append(p.slice)

def p_ConditionalOrExpression(p):
    '''
    ConditionalOrExpression : ConditionalAndExpression
    | ConditionalOrExpression LOGICAL_OR ConditionalAndExpression
    '''
    if(len(p)==2):
        p[0] = p[1]
        return
    newPlace = ST.get_temp_var()
    p[0] = {
        'place' : newPlace,
    }
    if 'ret_type' in p[1].keys():
        type1 = p[1]['ret_type'][0]
        if p[1]['ret_type'][1] != 0:
            raise Exception("Error")
    else:
        type1 = p[1]['type']

    if 'ret_type' in p[3].keys():
        type2 = p[3]['ret_type'][0]
        if p[3]['ret_type'][1] != 0:
            raise Exception("Error")
    else:
        type2 = p[3]['type']

    if type1 == "INT" and type2 == "INT":
        l1 = ST.make_label()
        TAC.emit(newPlace,p[1]['place'],'','=', ST)
        TAC.emit('ifgoto',p[1]['place'],'eq 1',l1, ST)
        TAC.emit(newPlace, p[1]['place'], p[3]['place'], '|', ST)
        TAC.emit('label',l1,'','', ST)
        p[0]['type'] = 'INT'
    else:
        raise Exception('Error: Type is not compatible' + p[1]['place'] + ',' + p[3]['place'] + '.')
    rules_store.append(p.slice)

def p_ConditionalExpression(p):
    '''
    ConditionalExpression : ConditionalOrExpression
    | ConditionalOrExpression QUESTION Expression COLON ConditionalExpression
    '''
    if len(p) == 2:
        p[0] = p[1]
    rules_store.append(p.slice)

def p_AssignmentExpression(p):
    '''
    AssignmentExpression : ConditionalExpression
    | Assignment
    | LAMBDA LambdaExpression
    '''
    if len(p) == 2:
        p[0] = p[1]
    rules_store.append(p.slice)

def p_Assignment(p):
    '''
    Assignment : LeftHandSide AssignmentOperator AssignmentExpression
    '''
    if 'access_type' not in p[1].keys():
        attributes = ST.lookup(p[1]['place'])
        if attributes == None:
            raise Exception("Undeclared variable used: %s" %(p[1]['place']))
        if 'is_array' in attributes and attributes['is_array']:
            raise Exception("Array '%s' not indexed properly" %(p[1]['place']))
        if 'ret_type' in p[3].keys() and p[3]['ret_type'][0] == attributes['type']:
            TAC.emit(p[1]['place'], p[3]['place'], '', p[2], ST)
        elif attributes['type'] == p[3]['type']:
            TAC.emit(p[1]['place'], p[3]['place'], '', p[2], ST)
        else:
            raise Exception("Type Mismatch for symbol: %s" %(p[3]['place']))
    else:
        dest = p[1]['name'] + '[' + p[1]['index'] + ']'
        TAC.emit(dest, p[3]['place'], '', p[2], ST)


    rules_store.append(p.slice)

def p_LeftHandSide(p):
    '''
    LeftHandSide : Name
    | FieldAccess
    | ArrayAccess
    '''
    p[0] = p[1]
    rules_store.append(p.slice)

def p_AssignmentOperator(p):
    '''
    AssignmentOperator : ASSIGN
    | MULTEQ
    | DIVEQ
    | MODEQ
    | PLUSEQ
    | MINUSEQ
    | LSHIFTEQ
    | RSHIFTEQ
    '''
    p[0] = p[1]

    rules_store.append(p.slice)
    #To check if I missed something

def p_Expression(p):
    '''
    Expression : AssignmentExpression
    '''
    p[0] = p[1]
    rules_store.append(p.slice)

def p_LambdaExpression(p):
    '''
    LambdaExpression : L_PAREN FormalParameterList R_PAREN LAMBDA_TOKEN Block
    | L_PAREN R_PAREN LAMBDA_TOKEN Block
    '''
    rules_store.append(p.slice)

def p_ConstantExpression(p):
    '''
    ConstantExpression : Expression
    '''
    p[0] = p[1]
    rules_store.append(p.slice)

def p_error(p):
    print("Syntax Error in line %d" %(p.lineno))
    sys.exit()


def parser_main():
    tokens = lexer.tokens
    parser = yacc.yacc()
    inputfile = sys.argv[1]
    file_out = inputfile.split('/')[-1].split('.')[0]
    code = open(inputfile, 'r').read()
    code += "\n"

    try:
        d = int(sys.argv[2])
    except:
        d = 0
    parser.parse(code, debug=d)

    # print("******************")
    # for i in TAC.code_list:
        # print(i)
    TAC.generate()
    # ST.print_scope_table()

if __name__ == "__main__":
    parser_main()
    # print(class_table)
