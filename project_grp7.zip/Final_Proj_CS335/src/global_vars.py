symbol_table = None

temp_var_set = set()

counter = 0

curr_class = None

members = []

func_members = []
