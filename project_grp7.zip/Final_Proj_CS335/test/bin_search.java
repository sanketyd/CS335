class bin_search{
    int print_arr(int len){
        return len;
    }

    int main(){
        int []a = new int[10];
        for(int i = 0; i < 10; i++){
            a[i - 1] = i;
        }
        int l = print_arr(10);
        return 0;
    }
}
