class Debug {
    int add(int a, int b) {
        return a + b;
    }
    int main() {
        int a = 19;
        int b = 2;
        int d = 1 ;
        boolean c;
        c = a && b || d;
        c = ~a;
    }
}
