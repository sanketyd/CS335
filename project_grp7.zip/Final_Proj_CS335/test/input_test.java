class input_test{
    int main(){
        int a;
        input(a);
        println(a);
        return 0;
    }
}
