class Debug {
    int add(int a) {
        return a;
    }
    int main() {
        int b = add(10);
        println(b);
    }

}
