class sanket_test{
    void main(){
        int a = 3;
        int b = 2;
        int c = 99;
        switch(a) {
            case 1: println(1);
            case 2: println(2);
            case 3: println(3);
            default: println(-1);
        }
        println(a);
    }
}
