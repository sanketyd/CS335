class Wh {

	int main(){
	int b = 0;
	int raktim = 5;
	do
        {
        b++;
	raktim = raktim - 1;
        }while(raktim > 1);

        /* Copy remaining elements of L[] if any */
   }
}
