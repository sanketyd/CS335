class Wh {
	int main(){
	int a = 0;
	for (int raktim = 1;raktim < 5;)
    {
		a = a + 2;
        println(raktim);
        raktim++;
    }
    return 0;
   }
}
