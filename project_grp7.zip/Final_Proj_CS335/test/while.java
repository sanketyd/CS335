class Wh {

    int main(){
        int raktim = 1;
        while (raktim < 5)
        {
		raktim++;
        println(raktim);

        }

        /* Copy remaining elements of L[] if any */
    }
}
