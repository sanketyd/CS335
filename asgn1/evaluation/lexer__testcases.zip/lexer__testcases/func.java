public class func {
	public void foo() {
		int i = 1;
	}

	public static void main(String[] args) {
		foo();
	}
}