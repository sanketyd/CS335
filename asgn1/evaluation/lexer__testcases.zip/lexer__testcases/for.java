public class for {
	public static void main(String[] args) {
		int i=6;
		for(; i <= 8 && i >= 6 && i != 7; i++) {
			if(i >= 0) {
				System.out.println("yes");
			} else {
				System.out.println("no");
			}
		}
	}
}